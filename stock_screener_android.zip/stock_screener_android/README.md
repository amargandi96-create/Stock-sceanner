# 📊 Value Stock Screener — Android (Kivy)

Aplikasi Android untuk screening saham Value Investing berbasis Python + Kivy.
Data real-time dari Yahoo Finance via `yfinance`.

---

## 🗂️ Struktur Proyek

```
stock_screener_android/
├── main.py                  # Entry point aplikasi
├── buildozer.spec           # Konfigurasi build APK
├── requirements.txt         # Dependensi Python
├── README.md
├── core/
│   ├── data_fetcher.py      # Ambil data dari Yahoo Finance
│   └── screener.py          # Logika filter & value score
├── screens/
│   ├── home_screen.py       # Layar input & konfigurasi filter
│   ├── result_screen.py     # Layar daftar hasil screening
│   └── detail_screen.py     # Layar detail satu saham
└── assets/
    └── icon.png             # (Opsional) icon aplikasi
```

---

## 🖥️ Cara Test di PC Dulu (Windows/Mac/Linux)

### 1. Install dependensi
```bash
pip install kivy yfinance pandas numpy
```

### 2. Jalankan
```bash
python main.py
```

Aplikasi akan terbuka di jendela 400×700px (simulasi layar HP).

---

## 📱 Build APK Android

Build APK membutuhkan **Linux atau WSL2** (Windows Subsystem for Linux).

### Opsi A — Linux / WSL2

#### 1. Install buildozer
```bash
pip install buildozer
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip
```

#### 2. Build APK (pertama kali butuh ~30 menit, download SDK/NDK)
```bash
cd stock_screener_android
buildozer android debug
```

#### 3. APK ada di:
```
bin/valuestockscreener-1.0-debug.apk
```

Transfer ke HP via kabel/Google Drive, aktifkan "Install dari sumber tidak dikenal", install.

---

### Opsi B — Google Colab (Gratis, tanpa Linux)

1. Buka [Google Colab](https://colab.research.google.com)
2. Upload seluruh folder `stock_screener_android`
3. Jalankan cell berikut:

```python
# Install buildozer
!pip install buildozer

# Install dependensi sistem
!apt-get install -y git zip unzip openjdk-17-jdk python3-pip \
    libffi-dev libssl-dev

# Build
import os
os.chdir("/content/stock_screener_android")
!buildozer android debug 2>&1 | tail -20
```

4. Download APK dari `/content/stock_screener_android/bin/`

---

## 🎯 Fitur Aplikasi

| Layar | Fitur |
|---|---|
| **Home** | Pilih pasar (US/IDX/Custom), slider filter, tombol Run |
| **Hasil** | Daftar saham lolos filter + Value Score, tab semua data |
| **Detail** | Graham checklist, semua metrik, skor visual |

---

## ⚠️ Disclaimer

Hanya untuk edukasi. Bukan saran investasi. Selalu DYOR.
